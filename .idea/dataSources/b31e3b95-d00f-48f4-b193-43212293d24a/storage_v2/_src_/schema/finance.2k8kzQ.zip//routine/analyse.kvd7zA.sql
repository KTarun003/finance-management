create
    definer = root@localhost procedure analyse()
BEGIN
	declare Pinterest,Pprinciple,Cinterest,Cprinciple,Iperc,Pperc float;
    select interest,principle into Pinterest,Pprinciple from analytics where `month` = (month(CURRENT_DATE())-1) AND `year` = YEAR(CURRENT_DATE());
    select sum(principle),sum(interest) into Cprinciple,Cinterest from recoveries where MONTH(`date`) = MONTH(CURRENT_DATE);
    set Iperc = ((Cinterest - Pinterest)/Pinterest)*100;
    set Pperc = ((Cprinciple - Pprinciple)/Pprinciple)*100;
    if((select exists(select * from analytics where month = month(CURRENT_DATE()) AND year = YEAR(CURRENT_DATE))) = 0) then
		insert into analytics values(month(current_date()),year(current_date()),Cprinciple,Cinterest,Pperc,Iperc);
	
    else
		update analytics set principle = Cprinciple,interest = Cinterest , p_percent = Pperc , i_percent = Iperc where `month` = (month(CURRENT_DATE())) AND `year` = YEAR(CURRENT_DATE());
    end if;
END;

